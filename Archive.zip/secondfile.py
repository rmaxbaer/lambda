def brookeiscute(event):
    print('cute brooke')
    for key, value in event.items():
        print(key, value)