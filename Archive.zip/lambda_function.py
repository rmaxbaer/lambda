import json

def lambda_handler(event, context):
    print('its chewsday. bloody good day for a pint, init bruv 6' )
    # lambda_function = 2
    # lambda_function = 3
